aldex <- function( reads, conditions, mc.samples=1024, t.significant=0.01, t.meaningful=2 ) {

    # The 'reads' data.frame MUST have row
    # and column names that are unique, and
    # looks like the following:
    #
    #              T1a T1b  T2  T3  N1  N2
    #   Gene_00001   0   0   2   0   0   1
    #   Gene_00002  20   8  12   5  19  26
    #   Gene_00003   3   0   2   0   0   0
    #   Gene_00004  75  84 241 149 271 257
    #   Gene_00005  10  16   4   0   4  10
    #   Gene_00006 129 126 451 223 243 149
    #       ... many more rows ...
    #
    #
    # The 'conditions' vector must be coercable
    # to a two-level factor that indicates which
    # conditions are to be compared.
    #
    # Note that we do NOT do nesting of technical
    # replicates within biological replicates; instead
    # these should be run separately to asses the
    # relative magnitudes of these effects.

    # ---------------------------------------------------------------------
    # Fully validate and coerce the data into required formats

    reads <- as.data.frame( reads )
    if ( any( round(reads) != reads ) ) stop("not all reads are integers")
    if ( any( reads < 0 ) )             stop("one or more reads are negative")

    for ( col in names(reads) ) {
        if ( any( ! is.finite( reads[[col]] ) ) )  stop("one or more reads are not finite")
    }

    if ( length(rownames(reads)) == 0 ) stop("rownames(reads) cannot be empty")
    if ( length(colnames(reads)) == 0 ) stop("colnames(reads) cannot be empty")

    if ( length(rownames(reads)) != length(unique(rownames(reads))) ) stop ("row names are not unique")
    if ( length(colnames(reads)) != length(unique(colnames(reads))) ) stop ("col names are not unique")

    conditions <- as.factor( conditions )
    levels     <- levels( conditions )

    if ( length( conditions ) != ncol( reads ) ) stop("mismatch between 'lenght(conditions)' and 'ncol(reads)'")

    if ( length( levels ) != 2 ) stop("only two condition levels are currently supported")

    levels <- vector( "list", length( levels ) )
    names( levels ) <- levels( conditions )

    for ( l in levels( conditions ) ) {
        levels[[l]] <- which( conditions == l )
        if ( length( levels[[l]] ) < 2 ) stop("condition level '",l,"' has less than two replicates")
    }

    if ( mc.samples < 300 ) warning("upper and lower quantiles are unreliable when estimated with so few MC samples")

    stopifnot( 0 < t.significant && t.significant < 0.5 )
    stopifnot( 1 < t.meaningful )

    probs <- c(0.01,0.05,0.50,0.95,0.99)

    # ---------------------------------------------------------------------
    # Monte Carlo sample the frequencies of each sample via the Dirichlet distribution,
    # using the one-group objective reference prior of Berger and Bernardo

    nr <- nrow( reads )
    rn <- rownames( reads )

    p <- lapply( reads , function(col) { q <- t( rdirichlet( mc.samples, col + 0.5 ) ) ; rownames(q) <- rn ; q } )

    for ( i in 1:length(p) ) {
            if ( any( ! is.finite( p[[i]] ) ) ) stop("non-finite frequencies estimated")
    }

    # ---------------------------------------------------------------------
    # Take the log2 of the frequency and remove the noninformative subspace component

    l2p <- lapply( p, function(m) {
        apply( log2(m), 2, function(col) { col - mean(col) } )
    })

    for ( i in 1:length(l2p) ) {
        if ( any( ! is.finite( l2p[[i]] ) ) ) stop("non-finite log-frequencies were unexpectedly computed")
    }


#REMOVE p cuts peak memory of B. cereus dataset from 3.7G to 2.9G
	rm(p)
	gc()
#

    # ---------------------------------------------------------------------
    # Summarize the expression within and among groups
    
    expression <- vector( "list", 3 )
    names(expression) <- c( "among", "within", "sample" )
    expression$within <- list()
    
    cl2p <- NULL
    for ( m in l2p ) cl2p <- cbind( cl2p, m )
    expression$among <- t(apply( cl2p, 1, quantile, probs=probs, type=8 ))
    rm(cl2p)
    gc()
    
    for ( level in levels(conditions) ) {
        cl2p <- NULL
        for ( i in levels[[level]] ) cl2p <- cbind( cl2p, l2p[[i]] )
        expression$within[[level]] <- t(apply( cl2p, 1, quantile, probs=probs, type=8 ))
        rm(cl2p)
        gc()
    }

    expression$sample <- lapply( l2p, function(m) { t(apply( m, 1, quantile, probs=probs, type=8 )) } )

    # ---------------------------------------------------------------------
    # Compute differences between and within groups

    l2d <- vector( "list", 2 )
    names( l2d ) <- c( "between", "within" )
    l2d$within <- list()

    # abs( within-conditions difference ), between samples

    for ( level in levels(conditions) ) {
        for ( l1 in sort( levels[[level]] ) ) {
            for ( l2 in sort( levels[[level]] ) ) {
                if ( l2 <= l1 ) next
                l2d$within[[level]] <- cbind( l2d$within[[level]] , abs( l2p[[l1]] - l2p[[l2]] ) )
            }
        }
    }

    # Handle the case when the groups have different sample sizes
    # get the minimum number of within sample comparisons
    ncol.wanted <- min( sapply( l2d$within, ncol ) )
    l2d$within  <- lapply( l2d$within, function(arg) { arg[,1:ncol.wanted] } )    

    # Between condition difference (signed)

    for ( l1 in levels[[1]] ) {
        for ( l2 in levels[[2]] ) {
            l2d$between <- cbind( l2d$between , ( l2p[[l2]] - l2p[[l1]] ) )
        }
    }
###last use of l2p
    within.max <- matrix( 0 , nrow=nr , ncol=ncol.wanted )
    l2d$effect <- matrix( 0 , nrow=nr , ncol=ncol(l2d$between) )
    rownames(l2d$effect) <- rn
	
###the number of elements in l2d$between and l2d$within may leave a remainder when
  #recycling these random vectors. Warnings are suppressed because this is not an issue
  #for this calculation. In fact, any attempt to get rid of this error would
  #decrease our power as one or both vectors would need to be truncatedgg 20/06/2013
  
	options(warn=-1)
    
    for ( i in 1:nr ) {
        within.max[i,] <- apply( ( rbind( l2d$within[[1]][i,] , l2d$within[[2]][i,] ) ) , 2 , max )
        l2d$effect[i,] <- l2d$between[i,] / within.max[i,]
    }

	options(warn=0)

    rownames(within.max)   <- rn
    attr(l2d$within,"max") <- within.max
    rm(within.max)

    # ---------------------------------------------------------------------
    # Summarize differences

    l2s <- vector( "list", 2 )
    names( l2s ) <- c( "between", "within" )
    l2s$within <- list()

    l2s$between <- t(apply( l2d$between, 1, quantile, probs=probs, type=8 ))
    l2s$within  <- t(apply( attr(l2d$within,"max"), 1, quantile, probs=probs, type=8 ))
    
    effect  <- t(apply( l2d$effect, 1, quantile, probs=probs, type=8 ))

    # ---------------------------------------------------------------------
    # Selection criteria

   #significant <- apply( l2d$between, 1, function(row) { q <- quantile( row, probs=c(t.significant,1-t.significant), type=8 ) ; ! ( q[1] < 0 && 0 < q[2] ) } )

    #OLD calculated from between
    #significance <- apply( l2d$between, 1, function(row) { min( aitchison.mean( c( sum( row < 0 ) , sum( row > 0 ) ) + 0.5 ) ) } )
    #NEW calculated from effect
    significance <- apply( l2d$effect, 1, function(row) { min( aitchison.mean( c( sum( row < 0 ) , sum( row > 0 ) ) + 0.5 ) ) } )
    significant  <- ( significance <= t.significant )
    attr(significant,"threshold") <- t.significant
    
    meaning    <- abs( effect[,"50%"] )
    meaningful <- ( meaning >= t.meaningful )
    attr(meaningful,"threshold") <- t.meaningful

    called <- ( significant & meaningful )

    # ---------------------------------------------------------------------
    # Done

    rv <- list(
        expression = expression,
        difference = l2s,
        effect = effect,
        criteria = data.frame(
            significance = significance,
            significant  = significant,
            meaning      = meaning,
            meaningful   = meaningful,
            row.names    = rn
        )
    )
    attr(rv,"probs") <- probs
    class(rv) <- c( "aldex", class(rv) )
    on.exit( expr=gc(), add=TRUE )
    return(rv)

}


plot.aldex <- function( x, ..., type=c("MW","MA"),
    xlab=NULL, ylab=NULL, xlim=NULL, ylim=NULL,
    nbin=256, nrpoints=Inf, col=NULL, pch='.',
    meaning.col="cyan", meaning.pch=20, meaning.cex=0.25,
    signif.col="yellow", signif.pch=20, signif.cex=0.25,
    called.col="red", called.pch=20, called.cex=0.25,
    thres.line.col="darkgrey", thres.lwd=1
) {

    stopifnot( inherits( x, "aldex" ) )

    type <- match.arg(type)
    called <- x$criteria$significant & x$criteria$meaningful
    meaning <- x$criteria$meaningful
    signif <- x$criteria$significant

    if ( is.null(col) ) col <- blues9[9]

    if ( type == "MA" ) {

        if ( is.null(xlab) ) xlab <- expression( "Median" ~~ Log[2] ~~ "Combined-Expression Level" )
        if ( is.null(ylab) ) ylab <- expression( "Median" ~~ Log[2] ~~ "Between-Condition Difference" )

        if ( is.null(xlim) ) xlim <- range( x$expression$among[      ,"50%"] )
        if ( is.null(ylim) ) ylim <- range( x$difference$between [      ,"50%"] )

        smoothScatter( x$expression$among[      ,"50%"], x$difference$between[      ,"50%"], xlim=xlim, ylim=ylim, nbin=nbin, nrpoints=nrpoints, col=col, pch=pch, xlab=xlab, ylab=ylab )
        points       ( x$expression$among[meaning,"50%"], x$difference$between[meaning,"50%"], pch=meaning.pch, cex=meaning.cex, col=meaning.col )
        points       ( x$expression$among[signif,"50%"], x$difference$between[signif,"50%"], pch=signif.pch, cex=signif.cex, col=signif.col )
        points       ( x$expression$among[called,"50%"], x$difference$between[called,"50%"], pch=called.pch, cex=called.cex, col=called.col )

    } else if ( type == "MW" ) {

        if ( is.null(xlab) ) xlab <- expression( "Median" ~~ Log[2] ~~ "Within-Condition Difference" )
        if ( is.null(ylab) ) ylab <- expression( "Median" ~~ Log[2] ~~ "Between-Condition Difference" )

        if ( is.null(xlim) ) xlim <- range( x$difference$within [      ,"50%"] )
        if ( is.null(ylim) ) ylim <- range( x$difference$between[      ,"50%"] )

        smoothScatter( x$difference$within[      ,"50%"], x$difference$between[      ,"50%"], xlim=xlim, ylim=ylim, nbin=nbin, nrpoints=nrpoints, col=col, pch=pch, xlab=xlab, ylab=ylab )
        points(        x$difference$within[meaning,"50%"], x$difference$between[meaning,"50%"], pch=meaning.pch, cex=meaning.cex, col=meaning.col )
        points(        x$difference$within[signif,"50%"], x$difference$between[signif,"50%"], pch=signif.pch, cex=signif.cex, col=signif.col )
        points(        x$difference$within[called,"50%"], x$difference$between[called,"50%"], pch=called.pch, cex=called.cex, col=called.col )
        abline( a=0, b= attr(x$criteria$meaningful,"threshold"), col=thres.line.col, lwd=thres.lwd )
        abline( a=0, b=-attr(x$criteria$meaningful,"threshold"), col=thres.line.col, lwd=thres.lwd )
        abline( a=0, b= 1, col=thres.line.col, lwd=thres.lwd, lty=2 )
        abline( a=0, b=-1, col=thres.line.col, lwd=thres.lwd, lty=2 )

    } else stop("unkown plot type")

    invisible()
}


summary.aldex <- function( object, ... ) {
    
    stopifnot( inherits( object, "aldex" ) )
    x <- object
    rm(object)

    digits <- 3
    sort   <- FALSE
    median.only <- FALSE
    
    a <- as.list( match.call() )
    if ( ! is.null( a[["digits"]] ))        digits <- a$digits
    if ( ! is.null( a[["sort"]] ))          sort <- a$sort
    if ( ! is.null( a[["median.only"]] ))   median.only <- a$median.only
    
    y <- data.frame(x)
    yn <- names(y)
    
    for ( n in yn ) if ( is.numeric( y[[n]] ) ) y[[n]] <- round( y[[n]], digits=digits )
    
    yn <- gsub( "\\.([0-9])\\.$", ".q0\\1", yn )
    yn <- gsub( "\\.([0-9][0-9])\\.$", ".q\\1", yn )
    names(y) <- yn

    if ( median.only ) {
        is.quantile <- grepl( "\\.q([0-9][0-9])$", yn )
        not.median  <- ! grepl( "\\.q50$", yn )
        wanted <- ( ! is.quantile ) | ( ! not.median )
        y <- y[ , wanted ]
    }

    if ( sort ) y <- y[ order( y$effect.q50 , decreasing=TRUE ) , ] 
    
    return(y)    
}

